$('div')
  .css('color', 'gray');

$('div:first')
  .css('border', '2px solid blue');

$('#a')
  .css('background', 'brown');

$('#a p')
  .css('border', '2px solid black');

$('.b')
  .css('background', 'pink');

$('input[type="number"]')
  .css('background', 'yellow');
